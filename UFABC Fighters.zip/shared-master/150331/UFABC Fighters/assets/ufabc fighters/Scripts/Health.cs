﻿using UnityEngine;
using System.Collections;


public class Health : MonoBehaviour {
	Constants constant;
	public float _hp;
	float scale;

	void Start () {
		constant = (Constants)GameObject.Find("World").GetComponent("Constants");
		_hp = constant.getHP ();
	}

	void Update () {
		/*if (_hp <= 0) {
			Destroy(gameObject);
		}*/
	}

	public void damaged(float damage){
		_hp -= damage;

	}

	public float getHP(){
		return _hp;
	}



}
