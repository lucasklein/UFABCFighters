﻿using UnityEngine;
using System.Collections;

public class MainMenuGUI : MonoBehaviour {
	[SerializeField]
	GUISkin _GUISkin;
	
	[SerializeField]
	Texture2D _mainMenuBg;

	[SerializeField]
	Texture2D _title;

	[SerializeField]
	Texture2D _newGameButton;

	[SerializeField]
	Texture2D _quitButton;

	Rect newbtn, quitbtn;

	void OnGUI(){
		GUI.skin = _GUISkin;

		GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), _mainMenuBg);

		GUI.DrawTexture(new Rect((Screen.width - _title.width)/2, 20, _title.width, _title.height),_title);

		newbtn = new Rect(Screen.width/2 - 290,Screen.height - (_newGameButton.height+60), 270, _newGameButton.height);

		quitbtn = new Rect(Screen.width/2+ 20, Screen.height - (_quitButton.height+ 60), 270, _quitButton.height);

		if (GUI.Button(newbtn,_newGameButton)){
			Application.LoadLevel("RedFloor");
		}

		if (GUI.Button(quitbtn,_quitButton)){
			Application.Quit();
		}

	}
}

