﻿using UnityEngine;
using System.Collections;

public class Keyboard : MonoBehaviour {
	PlayerAction pa1, pa2;
	Constants constant;

	GameObject P1,P2;
	Vector3 theScale1, theScale2;
	bool girar = false;

	void Start () {
		pa1 = (PlayerAction)GameObject.Find("P1").GetComponent("PlayerAction");
		pa2 = (PlayerAction)GameObject.Find("P2").GetComponent("PlayerAction");

		P1 = GameObject.Find ("P1");
		P2 = GameObject.Find ("P2");
		constant = (Constants)GameObject.Find("World").GetComponent("Constants");
		theScale1 = P1.transform.localScale;
		theScale2 = P2.transform.localScale;

		
		theScale2.x = theScale1.x * -1;
		P2.transform.localScale = theScale2;
		pa1.setDirection (1);
		pa2.setDirection (-1);
	}

	void Update () {

		//Since both player will use same keyboard, we need to handle both inputs together
		//PLAYER 1
			if (Input.GetKeyDown(constant.getP1JumpKey())) {
				pa1.jump();
			}
			if (Input.GetKey(constant.getP1RighthKey())) {
				pa1.walk (1);
			}
			if (Input.GetKey (constant.getP1LeftKey ())) {
				pa1.walk (-1);
			}
			if (Input.GetKey(constant.getP1PunchKey())) {
				pa1.move1();
			}
			if (Input.GetKey(constant.getP1KickKey())) {
				pa1.move2();
			}
			//PLAYER 2
			if (Input.GetKeyDown(constant.getP2JumpKey())) {
				pa2.jump();
			}
			if (Input.GetKey(constant.getP2RighthKey())) {
				pa2.walk (1);
			}
			if (Input.GetKey(constant.getP2LeftKey())) {
				pa2.walk (-1);

			}
			if (Input.GetKey(constant.getP2PunchKey())) {
				pa2.move1();
			}
			if (Input.GetKey(constant.getP2KickKey())) {
				pa2.move2();
			}
	}

	void LateUpdate(){
		//First we need to check who is on each side of the screen to adjust the animations:\
		if (P2.transform.position.x > P1.transform.position.x && girar) {
			gira ();
			girar = !girar;

		}
		else if (P2.transform.position.x < P1.transform.position.x && !girar) {
			gira ();
			girar = !girar;
		}
	}

	void gira(){
		theScale1 = theScale2;
		theScale2.x = theScale1.x * -1;
		P2.transform.localScale = theScale2;
		P1.transform.localScale = theScale1;
		pa1.setDirection (pa1.getDirection()*-1);
		pa2.setDirection (pa2.getDirection()*-1);
	}
}
