﻿using UnityEngine;
using System.Collections;

public class AI_naive : MonoBehaviour {
	GameObject Opponent;
	CharacterController control;
	PlayerAction pa;
	string opponentName;
	void Start () {
		if (this.name == "P1")
			opponentName = "P2";
		else
			opponentName = "P1";
		Opponent = GameObject.Find (opponentName);
		control = GetComponent<CharacterController>();
		pa = (PlayerAction)this.GetComponent("PlayerAction");
	}
	void Update () {
		if (Opponent.transform.position.x > this.transform.position.x + 3.000f) {
			if(Random.Range(1,51) == 1){
				pa.jump ();
			}
			pa.walk (1);
		}
		else if(Opponent.transform.position.x < this.transform.position.x - 3.000f){
			if(Random.Range(1,51) == 1){
				pa.jump ();
			}
			pa.walk (-1);
		}
		else {
			if(Random.Range(1,3) == 1){
				pa.move1 ();
			}
			else{
				pa.move2 ();
			}
		}
	}
}