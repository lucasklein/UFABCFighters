﻿using UnityEngine;
using System.Collections;

public class Kick : MonoBehaviour {
	Constants constant;
	float recoil = 0.3f;
	GameObject rcStart;
	GameObject rcEnd;

	void Start () {
		constant = (Constants)GameObject.Find("World").GetComponent("Constants");
		rcStart = new GameObject ("rcKickStart");
		rcEnd = new GameObject("rcKickEnd");
		rcStart.transform.parent = this.transform;
		rcEnd.transform.parent = this.transform;
		
		rcStart.transform.localPosition = new Vector3 (constant.getRyuKickX(), constant.getRyuKickY0(), 0); 
		rcEnd.transform.localPosition = new Vector3 (constant.getRyuKickWidth(), constant.getRyuKickY1(), 0);
	}
	void Update () {}

	public void RayCasting (){
		StartCoroutine ("Wait");
	}

	void WrappedRC(){
		Debug.DrawLine (rcStart.transform.position, rcEnd.transform.position, Color.red, 0.3f);
		
		RaycastHit hit;
		if (Physics.Linecast (rcStart.transform.position, rcEnd.transform.position, out hit)) {
			hit.collider.gameObject.SendMessage("Hitted", recoil);
		}
	}

	IEnumerator Wait(){
		yield return new WaitForSeconds (0.3f);
		WrappedRC ();
	}
}