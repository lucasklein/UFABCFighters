﻿using UnityEngine;
using System.Collections;

//THIS MUST BE SINGLETON (DONT FORGET TO CONVERT BEFORE A2)
public class Constants : MonoBehaviour {
	//Character constants
	float ryuPunchY1  = 0.265f;
	float ryuPunchWidth = 0.550f;
	float ryuKickX  = 0.026f;
	float ryuKickY0  = -0.024f;
	float ryuKickY1  = 0.265f;
	float ryuKickWidth = 0.550f;
	//Mechanical constants
	[SerializeField]
	float _cdPunch = 0.3f;
	//Physical constants
	[SerializeField]
	float _moveSpeed = 5.0f;
	[SerializeField]
	float _jumpSpeed = 20.0f;
	[SerializeField]
	float _gravity = 1.0f;
	[SerializeField]
	float _recoilSpeed = 5.0f;
	[SerializeField]
	float _HP = 100.0f;

	//Player1 keys
	[SerializeField]
	string _p1Punch = "c";
	[SerializeField]
	string _p1Kick = "f";
	[SerializeField]
	string _p1Jump = "w";
	[SerializeField]
	string _p1Right = "d";
	[SerializeField]
	string _p1Left = "a";

	//Player2 keys
	[SerializeField]
	string _p2Punch = "l";
	[SerializeField]
	string _p2Kick = "k";
	[SerializeField]
	string _p2Jump = "up";
	[SerializeField]
	string _p2Right = "right";
	[SerializeField]
	string _p2Left = "left";

	void Start () {}
	void Update () {}

	//GET
	//character
	public float getRyuPunchY1(){
		return ryuPunchY1;
	}
	public float getRyuPunchWidth(){
		return ryuPunchWidth;
	}
	public float getRyuKickX(){
		return ryuKickX;
	}
	public float getRyuKickY0(){
		return ryuKickY0;
	}
	public float getRyuKickY1(){
		return ryuKickY1;
	}
	public float getRyuKickWidth(){
		return ryuKickWidth;
	}

	//mechanical
	public float getCDPunch(){
		return _cdPunch;
	}
	//physical
	public float getMoveSpeed(){
		return _moveSpeed;
	}
	public float getJumpSpeed(){
		return _jumpSpeed;
	}
	public float getGravity(){
		return _gravity;
	}
	public float getRecoilSpeed(){
		return _recoilSpeed;
	}
	public float getHP(){
		return _HP;
	}
	//p1 keys
	public string getP1PunchKey(){
		return _p1Punch;
	}
	public string getP1KickKey(){
		return _p1Kick;
	}
	public string getP1RighthKey(){
		return _p1Right;
	}
	public string getP1LeftKey(){
		return _p1Left;
	}
	public string getP1JumpKey(){
		return _p1Jump;
	}
	//p2 keys
	public string getP2KickKey(){
		return _p2Kick;
	}
	public string getP2PunchKey(){
		return _p2Punch;
	}
	public string getP2RighthKey(){
		return _p2Right;
	}
	public string getP2LeftKey(){
		return _p2Left;
	}
	public string getP2JumpKey(){
		return _p2Jump;
	}
}
