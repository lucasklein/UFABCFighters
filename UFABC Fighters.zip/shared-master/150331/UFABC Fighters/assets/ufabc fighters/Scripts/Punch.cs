﻿using UnityEngine;
using System.Collections;

public class Punch : MonoBehaviour {
	Constants constant;
	float recoil = 0.2f;
	GameObject rcStart;
	GameObject rcEnd;

	void Start () {
		constant = (Constants)GameObject.Find("World").GetComponent("Constants");

		rcStart = new GameObject ("rcPunchStart");
		rcEnd = new GameObject("rcPunchEnd");
		rcStart.transform.parent = this.transform;
		rcEnd.transform.parent = this.transform;

		rcStart.transform.localPosition = new Vector3 (0, constant.getRyuPunchY1(), 0); 
		rcEnd.transform.localPosition = new Vector3 (constant.getRyuPunchWidth(), constant.getRyuPunchY1(), 0);
	}

	void Update () {}

	public void RayCasting (){
		Debug.DrawLine (rcStart.transform.position, rcEnd.transform.position, Color.red, 0.3f);

		RaycastHit hit;
		if (Physics.Linecast (rcStart.transform.position, rcEnd.transform.position, out hit)) {
		hit.collider.gameObject.SendMessage("Hitted", recoil);
		}
	}
}
