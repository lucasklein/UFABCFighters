﻿using UnityEngine;
using System.Collections;

public class PlayerAction : MonoBehaviour {
	CharacterController controller;
	
	Constants constant;
	Punch punch;
	Kick kick;
	Health health;
	[SerializeField]
	float _damage;
	float delay;
	int direction;

	float _moveSpeed;	
	float _jumpSpeed;
	float _gravity;
	float _recoilSpeed;

	bool canMove;
	bool canPlay;
	
	float cdTime;
	float recoilTime;

	Transform t;

	Vector3 velocity;

	Animator a;

	void Start () {
		controller = GetComponent<CharacterController>();
		//init constants
		constant = (Constants)GameObject.Find("World").GetComponent("Constants");
		punch = (Punch)this.GetComponent("Punch");
		kick = (Kick)this.GetComponent("Kick");
		health = (Health)this.GetComponent("Health");

		_moveSpeed = constant.getMoveSpeed();
		_gravity = constant.getGravity();
		_jumpSpeed = constant.getJumpSpeed();
		_recoilSpeed = constant.getRecoilSpeed();

		canMove = true;
		canPlay = true;
		cdTime = -constant.getCDPunch();
		recoilTime = 0.0f;

		t = this.transform;

		//Animators
		a = (Animator)this.GetComponent ("Animator");
		a.Play ("StartRyu");
	}

	void Update () {
		//gravity
		if (!controller.isGrounded) {
			velocity.y -= _gravity;
		}
		//update position
		move ();
	}
	
	public void walk(int dir){
		//x-axis
		if (canMove 
		    && (!a.GetCurrentAnimatorStateInfo (0).IsName ("Punch") && !a.GetCurrentAnimatorStateInfo (0).IsName ("Kick"))){
			velocity.x = dir * _moveSpeed;

			if(dir > 0){
				if(controller.isGrounded){
					a.Play("MoveForward");
				}else{
					a.Play("Jump");
				}
			}
			else{
				if(controller.isGrounded){
					a.Play("MoveBackward");
				}else{
					a.Play("Jump");
				}
			}
			
			delay = 0.05f;
			cdTime = Time.time + 0.05f;//parametrizar


		}
	}
	public void jump(){
		if (canPlay) {
			if (Time.time > cdTime + delay 
			    || a.GetCurrentAnimatorStateInfo (0).IsName ("MoveForward") ||
			    a.GetCurrentAnimatorStateInfo (0).IsName ("MoveBackward")) {
				if (controller.isGrounded) {
					if (!a.GetCurrentAnimatorStateInfo (0).IsName ("Punch") || !a.GetCurrentAnimatorStateInfo (0).IsName ("Kick")) {
						velocity.y = _jumpSpeed;
						a.Play ("Jump");
					}
				}
			}
		}
	}

	public void move1(){
		if (canPlay) {
			if (controller.isGrounded) {
				//				if (Time.time > cdTime + constant.getCDPunch ()) {
				if (Time.time > cdTime + delay) {
					if (!a.GetCurrentAnimatorStateInfo (0).IsName ("Punch") || 
						!a.GetCurrentAnimatorStateInfo (0).IsName ("MoveForward") ||
					    !a.GetCurrentAnimatorStateInfo (0).IsName ("MoveBackward") ||
					    !a.GetCurrentAnimatorStateInfo (0).IsName ("Kick")) {
						punch.RayCasting ();
						a.Play ("Punch");
						delay = constant.getCDPunch ();
						cdTime = Time.time + delay;
					}
				}
			} else {
				//air punch
			}
		}
	}
	public void move2(){
		if (canPlay) {
			if (controller.isGrounded) {
				if (Time.time > cdTime + delay) {
					if (!a.GetCurrentAnimatorStateInfo (0).IsName ("Punch") || 
					    !a.GetCurrentAnimatorStateInfo (0).IsName ("MoveForward") ||
					    !a.GetCurrentAnimatorStateInfo (0).IsName ("MoveBackward") ||
					    !a.GetCurrentAnimatorStateInfo (0).IsName ("Kick")) {
						kick.RayCasting ();
						a.Play ("Kick");
						delay = 0.5f;
						cdTime = Time.time + delay;
					}
				}
			} else {
				//air punch
			}
		}
	}


	void move(){
		if (canPlay) {
			velocity = transform.TransformDirection (velocity);
			controller.Move (velocity * Time.deltaTime);
			if (Time.time < recoilTime) {
				if(direction == -1){
					velocity.x += 1;
				}
				else if(direction == 1){
					velocity.x -= 1;
				}
			} else {
				velocity.x = 0;
				canMove = true;
			}
		}
	}

	void Hitted(float recoilInfo){
		health.damaged (_damage);
		recoil (recoilInfo);
		a.Play ("Damage");
		if (health.getHP() == 0){
		/*	a.Play ("Death");
			t.position = new Vector2(this.transform.position.x,6.56f);
			t.rotation = new Vector2(-0.5f,10f);
			this.transform.position = t.position;
			this.transform.rotation = t.rotation;
			Dead();*/
			Destroy(gameObject);
		}
	}

	void recoil(float modifier){
		//		velocity.x = _recoilSpeed * modifier;
		canMove = false;
		recoilTime = Time.time + 0.2f;//parametrizar
	}

	void Dead(){
		a.enabled = false;
		this.canMove = false;
		this.canPlay = false;
	}
	
	public void setDirection(int dir){
		direction = dir;
	}
	public int getDirection(){
		return direction;
	}
}
