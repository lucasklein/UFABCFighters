﻿using UnityEngine;
using System.Collections;

public class HealthBar : MonoBehaviour {
	Health hp;

	[SerializeField]
	GUISkin _GUISkin;

	// Use this for initialization
	void Start () {
		hp = (Health)this.GetComponent ("Health");
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnGUI(){
		GUI.skin = _GUISkin;
		if (this.name == "P1") {
			GUI.HorizontalScrollbar (new Rect ( 10, 10, 200, 20), 0, hp.getHP(), 0, 100);
		}
		if (this.name == "P2") {
			GUI.HorizontalScrollbar (new Rect ( Screen.width - 210, 10, 200, 20), 0, hp.getHP(), 0, 100);
		}

	}
	

}
